/*
is this model still needed anymore?
*/


/*
import config from './config';

let CartContentSchema = {
  "fields": {
    "id": {
      "type": "uuid",
      "default": {
        "$db_function": "uuid()"
      }
    },
    "service_id": {
      "type": "uuid"
    },
    "product_id": {
      "type": "uuid"
    },
    "subscription": {
      "type": "int"
    },
    "created_at": {
      "type": "timestamp", 
      "default" : {
        "$db_function": "now()"
      } 
    },
    "updated_at": {
      "type": "timestamp"
    }
  },
  "key": [["id"], "created_at"],
}

let cartContent = db.add_model('cart_list', CartContentSchema);

export default cartContent;*/



/*
import mongoose, {Schema} from 'mongoose';
import timestamp from 'mongoose-timestamp';
import db from './config';

let CartContentSchema = new Schema({
  service_id: {
    type: Schema.Types.ObjectID,
    ref: 'Service',
    required: true
  },

  product: {
    type: Schema.Types.ObjectId,
    ref: Product,
    required: true
  },

  Subcription: {
    type: Number,
    required: true
  }
  
})

CartContentSchema.plugin(timestamp, {
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

CartContentSchema.pre('save', function(next){
  let cart = this;
  remove cart.app_code;
})

CartContentSchema.methods.safeJSON = function(){
  let cart = this.toJSON();
  remove cart.app_code;
  return cart;
}

export default db.model("Cart_list", CartContentSchema);
*/