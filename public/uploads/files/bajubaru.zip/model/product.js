import config from './config';

let ProductSchema = {
  "fields": {
    "id": {
      "type": "uuid",
      "default": {
        "$db_function": "uuid()"
      }
    },
    "service_id": {
      "type": "uuid"
    },
    "product_id": {
      "type": "uuid"
    },
    "subscribe_id": {
      "type": "uuid"
    },
    "photo": {
      "type": "varchar"
    },
    "description": {
      "type": "varchar"
    },
    "photo": {
      "type": "varchar"
    },
    "fee": {
      "type": "int"
    },
    "fee_type": {
      "type": "varchar"
    },
    "created_at": {
      "type": "timestamp", 
      "default" : {
        "$db_function": "now()"
      } 
    },
    "updated_at": {
      "type": "timestamp"
    }
  },
  "key": [['id'], 'created_at'],
  "indexes": ["service_id", "product_id", "subscribe_id"]
}

let product = db.add_model('product', ProductSchema);

export default product;

/*
import mongoose, {Schema} from 'mongoose';
import db from './config';

let ProductSchema = new Schema({
  service_id: {
    type: Schema.Types.ObjectID,
    ref: 'Service',
    required: true
  }

  product_name: { 
    type: String, 
    required: true
  },

  detail: { 
    photo: {
      type: String,
      required: false
    },
    description: {
      type: String, 
      required: true
    }
  },

  fee: {
    type: Number,
    required: true
  },

  fee_type: {
    type: String,
    required: true
  },

  subscriber: [
    {
      user: {
        type: Schema.Types.ObjectID,
        ref: 'User',
        required: true
      },

      registered_date: {
        type: Date,
        required: true
      },

      start_date: {
        type: Date,
        required: true
      }
      
      expired_date: {
        type: Date,
        required: true
      },

      payment: {
        type: Schema.Types.ObjectID,
        ref: 'Payment',
        required: true
      }
    }
  ]

})

ProductSchema.pre('save', function(next){
  let product = this;
})


ProductSchema.methods.safeJSON = function(){
  let product = this.toJSON();
  remove product.app_code;
  return product;
}

export default db.model("Product", ProductSchema);
*/