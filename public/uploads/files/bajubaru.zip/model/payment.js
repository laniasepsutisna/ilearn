import config from '../config';

let PaymentSchema = {
  "fields": {
    "id": {
      "type": "uuid",
      "default": {
        "$db_function": "uuid()"
      }
    },
    "service_id": {
      "type": "uuid"
    },
    "cart_id": {
      "type": "uuid"
    },
    "method": {
      "type": "varchar"
    },
    "status": {
      "type": "varchar"
    },
    "created_at": {
      "type": "timestamp", 
      "default" : {
        "$db_function": "now()"
      } 
    },
    "updated_at": {
      "type": "timestamp"
    }
  },
  "key": ["id"],
  "indexes": ["cart_id", "service_id"]
}

let payment = db.add_model('payment', PaymentSchema);

export default payment;

/*
import mongoose, {Schema} from 'mongoose';
import timestamp from 'mongoose-timestamp';
import db from './config';

let PaymentSchema = new Schema({
  service_id: {
    type: Schema.Types.ObjectID,
    ref: 'Service',
    required: true
  },

  cart: {
  	type: Schema.Types.ObjectId,
  	ref: 'Cart',
  	required: true
  },

  method: {
  	type: String,
  	required: true
  },

  status: {
    type: String,
    required: true
  }
  
});

PaymentSchema.plugin(timestamp, {
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

CartContentSchema.pre('save', function(next){
  
})

CartContentSchema.methods.safeJSON = function(){
  let payment = this.toJSON();
  return payment;
}

export default db.model("Payment", PaymentSchema);
*/