import config from './config';

let SubscribeSchema = {
	"fields": {
		"id": {
			"type": "uuid",
			"default": {
				"$db_function": "uuid()"
			}
		},
		"user_id": {
			"type": "uuid"
		},
		"registered_date": {
			"type": "timestamp",
			"default": {
				"$db_function": "now()"
			}
		},
		"start_date": {
			"type": "timestamp"
		},
		"expired_date": {
			"type": "timestamp"
		},
		"payment_id": {
			"type": "uuid"
		}
	},
	"key": [["id"], "created_at"],
	"indexes": [["user_id"], "payment_id"]
}

let subscribe = db.add_model('subscribe', SubscribeSchema);

export default subscribe;