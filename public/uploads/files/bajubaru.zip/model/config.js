import secrets from '../config/Secrets';
import Apollo from 'apollo-cassandra';

let db = new Apollo(secrets.cassandra);

db.connect((err) => {
	if(err) {
		console.log('connect cassandra error');
		console.log(err);
	}
	/* do amazing things! */
});

export default db;

/*

import mongoose from 'mongoose';
import secrets from '../config/Secrets';

let db = mongoose.createConnection(secrets.db.host, 'membr.io', secrets.db.port, secrets.db.options);
db.on('error', function(err){
  console.log("Connection Mongoose error");
  console.log(err)
})

export default db;

*/