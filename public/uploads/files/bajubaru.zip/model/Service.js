import config from './config';

let ServiceSchema = {
	"fields": {
		"id": {
			"type": "uuid",
			"default": {
				"$db_function": "uuid()"
			}
		},
		"company_name": {
			"type": "varchar"
		},
		"domain_name": {
			"type": "varchar"
		},
    "created_at": {
      "type": "timestamp", 
      "default" : {
        "$db_function": "now()"
      } 
    },
    "updated_at": {
      "type": "timestamp"
    }
	},
	"key": [["id"], "created_at"],
	"indexes": ["company_name"]
}

let service = db.add_model('service', ServiceSchema);

export default service;

/*
import mongoose, {Schema} from 'mongoose';
import bcrypt from 'bcrypt';
import db from './config';

let ServiceSchema = new Schema({
	id: {
		type: String,
		default: uuid.v4(),
		unique: true,
		index: true,
		required: true
	},

	company_name: {
		type: String,
		required: true
	},

	domain_name: {
		type: String,
		required: true,
		unique: true
	}

})
*/