import config from './config';

let CartSchema = {
  "fields": {
    "id": {
      "type": "uuid",
      "default": {
        "$db_function": "uuid()"
      }
    },
    "service_id": {
      "type": "uuid"
    },
    "user_id": {
      "type": "uuid"
    },
    "product_id": {
      "type": "uuid"
    },
    "subscription": {
      "type": "int"
    },
    "created_at": {
      "type": "timestamp", 
      "default" : {
        "$db_function": "now()"
      } 
    },
    "updated_at": {
      "type": "timestamp"
    }
  },
  "key": [["id"], "created_at"],
  "indexes": [["service_id"], "user_id", "product_id"]
}

let cart = db.add_model('cart', CartSchema);

export default cart;

/*
import mongoose, {Schema} from 'mongoose';
import timestamp from 'mongoose-timestamp';
import db from './config';

let CartSchema = new Schema({
  service_id: {
    type: Schema.Types.ObjectID,
    ref: 'Service',
    required: true
  },

  member: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },

  list: [
    {
      type: Schema.Types.ObjectId,
      ref: 'Cart_list',
      default: null
    }
  ]
    
})

CartSchema.plugin(timestamp, {
  createdAt: 'created_at',
  updatedAt: 'updated_at',
});

CartSchema.pre('save', function(next){
  let cart = this;

})

CartSchema.methods.safeJSON = function(){
  let cart = this.toJSON();
  remove cart.app_code;
  return cart;
}

export default db.model("Cart", CartSchema);
*/