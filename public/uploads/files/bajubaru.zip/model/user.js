import config from './config';

let UserSchema = {
  "fields": {
    "id": {
      "type": "uuid",
      "default": {
        "$db_function": "uuid()"
      }
    },
    "username": {
      "type": "varchar"
    },
    "password": {
      "type": "varchar"
    },
    "avatar_url": {
      "type": "varchar"
    },
    "full_name": {
      "type": "varchar"
    },
    "email": {
      "type": "varchar"
    },
    "phone": {
      "type": "varchar"
    },
    "address": {
      "type": "text"
    },
    "referral_code": {
      "type": "varchar"
    },
    "created_at": {
      "type": "timestamp", 
      "default" : {
        "$db_function": "now()"
      } 
    },
    "updated_at": {
      "type": "timestamp"
    }
  },
  "key": [["id"], "created_at"],
  "indexes": [["username"], "email"]
}

let user = db.add_model('user', UserSchema);

export default user;

/*
import mongoose, {Schema} from 'mongoose';
import bcrypt from 'bcrypt';
import db from './config';

let UserSchema = new Schema({
  service_id: {
    type: Schema.Types.ObjectID,
    ref: 'Service',
    required: true
  },

  username: { 
    type: String, 
    required: true, 
    index: { 
      primary: true
    }
  },

  password: { 
    type: String, 
    required: true
  },

  profile: {
    avatar: String,
    full_name: String,
    email: String,
    phone: String,
    referral_code: String
  }
})

UserSchema.pre('save', function(next){
  let user = this;

  // only hash if modified
  if(!user.isModified('password')) 
    next();

  // generate salt
  bcrypt.genSalt(10, (err, salt)=>{
    if(err) return next(err);

    bcrypt.hash(user.password, salt, (err, hash)=>{
      if(err) 
        return next(err);
      // override
      user.password = hash;
      next();
    })
  })
})

UserSchema.methods.comparePassword = function(){
  bcrypt.compare(candidate, this.password, (err, isMatch)=>{
    if(err) return cb(err);
    cb(null, isMatch);
  })
}

UserSchema.methods.safeJSON = function(){
  let user = this.toJSON();
  delete user.password;
  return user;
}

export default db.model("User", UserSchema);
*/